$desktop = [System.Environment]::GetFolderPath('Desktop')
$appDir = (Get-Location).Path
$wsh = New-Object -ComObject WScript.Shell

$apps = @(
    @("Operator Antrian.lnk", "Operator Antrian.exe", "assets\icons\operator.ico", "Buka Panel Operator Antrian"),
    @("Kios Tiket.lnk", "Kios Tiket.exe", "assets\icons\kiosk.ico", "Buka Kios Ambil Tiket"),
    @("Layar TV Antrian.lnk", "Layar TV.exe", "assets\icons\tv.ico", "Buka Layar Monitor TV Ruang Tunggu")
)

foreach ($item in $apps) {
    $lnkPath = Join-Path $desktop $item[0]
    $sc = $wsh.CreateShortcut($lnkPath)
    $sc.TargetPath = Join-Path $appDir $item[1]
    $sc.WorkingDirectory = $appDir
    $sc.Description = $item[3]
    $ico = Join-Path $appDir $item[2]
    if (Test-Path $ico) { $sc.IconLocation = $ico }
    $sc.Save()
    Write-Host " [OK] Shortcut dibuat di Desktop: $($item[0])"
}
